import * as Y from "yjs";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { assistant, byteLength, content, summarize, tool, user, workload } from "./workloads";
import { Budget, captureSnapshot, getTools, invariant, validateText, type Api, type Sample } from "./harness";

export async function projectTools(api: Api, result: Sample, budget: Budget, count = workload.tools, large = false) {
    const docs = new api.SessionDocs();
    docs.accept(user());
    let projectionMs = 0;
    let rawPayloadBytes = 0;
    const batches: number[] = [];
    let batchTime = 0;
    for (let index = 0; index < count; index++) {
        const value = tool(index, large);
        rawPayloadBytes += byteLength(value.argumentsValue) + byteLength(value.resultValue);
        const started = performance.now();
        if (index % workload.toolsPerAssistant === 0) docs.accept(assistant(Math.floor(index / workload.toolsPerAssistant)));
        docs.accept(value.start);
        docs.accept(value.finish);
        const elapsed = performance.now() - started;
        projectionMs += elapsed;
        batchTime += elapsed;
        if ((index + 1) % 1_000 === 0 || index + 1 === count) {
            batches.push(batchTime);
            batchTime = 0;
            result.projection = { completedTools: index + 1, rawPayloadBytes, projectionMs, batch1000Ms: [...batches] };
            budget.checkpoint("project_tools", index + 1);
        } else if (index % 64 === 0) budget.check("project_tools", index + 1);
    }
    result.projection = { completedTools: count, rawPayloadBytes, projectionMs, batch1000Ms: batches };
    return docs;
}

export async function toolsScenario(api: Api, result: Sample, budget: Budget, encoding: "v1" | "v2", large = false) {
    const count = large ? 1 : workload.tools;
    const docs = await projectTools(api, result, budget, count, large);
    const completeStarted = performance.now();
    docs.completeTurn();
    result.completeMs = performance.now() - completeStarted;
    const replica = captureSnapshot(docs, result, budget, encoding);
    const records = getTools(replica.chat);
    invariant(records.size === count, `expected ${count} tool records, got ${records.size}`);
    let verified = 0;
    for (let index = 0; index < count; index++) {
        const expected = tool(index, large);
        const record = records.get(expected.id)!;
        invariant(record.get("status") === "completed", `${expected.id} status`);
        invariant(JSON.stringify(record.get("arguments")) === JSON.stringify(expected.argumentsValue), `${expected.id} arguments`);
        invariant(JSON.stringify(record.get("result")) === JSON.stringify(expected.resultValue), `${expected.id} result`);
        verified++;
        if (index % 256 === 0) budget.check("validate_tools", verified);
    }
    result.validation = { exact: true, verifiedTools: verified, activeTurnStatus:
        (replica.session.getMap("root").get("session") as Y.Map<unknown>).get("activeTurnStatus") };
    replica.chat.destroy(); replica.session.destroy(); docs.destroy();
}

function firstTool(snapshot: any): unknown {
    for (const entry of snapshot.entries) for (const block of entry.blocks) {
        if (block.type === "tool_call") return block.tool;
    }
    return null;
}

export async function viewScenario(api: Api, result: Sample, budget: Budget) {
    const docs = await projectTools(api, result, budget);
    const initialStarted = performance.now();
    const store = new api.SessionViewStore(docs.chat, docs.session);
    result.initialViewMs = performance.now() - initialStarted;
    let snapshots = 0;
    let unchangedToolIdentity = 0;
    let previousTool = firstTool(store.getSnapshot());
    store.subscribe(() => {
        snapshots++;
        const current = firstTool(store.getSnapshot());
        if (previousTool === current) unchangedToolIdentity++;
        previousTool = current;
    });
    const latencies: number[] = [];
    for (let index = 0; index < workload.asyncUpdates; index++) {
        const started = performance.now();
        docs.accept(assistant(workload.tools / workload.toolsPerAssistant, content(index, workload.chunkBytes, "async")));
        await Promise.resolve();
        latencies.push(performance.now() - started);
        budget.check("async_view", index + 1);
    }
    invariant(snapshots === workload.asyncUpdates, `view publishes ${snapshots} updates`);
    const expected = Array.from({ length: workload.asyncUpdates }, (_, i) => content(i, workload.chunkBytes, "async")).join("");
    const tail = store.getSnapshot().entries.at(-1).blocks.filter((block: any) => block.type === "text")
        .map((block: any) => block.text).join("");
    result.view = { snapshots, unchangedToolIdentity, latencyMs: summarize(latencies), rawLatencyMs: latencies };
    result.validation = validateText(tail, expected);
    store.destroy(); docs.destroy();
}

export async function legacyStreamScenario(api: Api, root: string, result: Sample, budget: Budget) {
    const { SessionDocStream } = await import(pathToFileURL(join(root, "examples/demo/session-doc-stream.ts")).href);
    const docs = new api.SessionDocs();
    const replica = { chat: new Y.Doc(), session: new Y.Doc() };
    const stream = new SessionDocStream(docs.chat, docs.session);
    let frames = 0, jsonBytes = 0, updateBytes = 0, applyMs = 0, projectionMs = 0;
    const connection = stream.subscribe((frame: any) => {
        frames++;
        jsonBytes += byteLength(frame);
        const bytes = Buffer.from(frame.update, "base64");
        updateBytes += bytes.length;
        const started = performance.now();
        Y.applyUpdate(replica[frame.doc as "chat" | "session"], bytes);
        applyMs += performance.now() - started;
    });
    const snapshotStarted = performance.now();
    Y.applyUpdate(replica.chat, Buffer.from(connection.snapshot.chat, "base64"));
    Y.applyUpdate(replica.session, Buffer.from(connection.snapshot.session, "base64"));
    result.initialSnapshot = { jsonBytes: byteLength(connection.snapshot), applyMs: performance.now() - snapshotStarted };
    docs.accept(user());
    for (let index = 0; index < workload.streamChunks; index++) {
        const text = content(index, workload.chunkBytes, "stream");
        const started = performance.now();
        docs.accept(assistant(0, text));
        projectionMs += performance.now() - started;
        if ((index + 1) % 2_048 === 0) {
            result.stream = { completedChunks: index + 1, frames, jsonBytes, updateBytes, applyMs, projectionMs };
            budget.checkpoint("stream", index + 1);
        } else if (index % 64 === 0) budget.check("stream", index + 1);
    }
    const completeStarted = performance.now();
    docs.completeTurn();
    result.completeMs = performance.now() - completeStarted;
    result.stream = { completedChunks: workload.streamChunks, frames, jsonBytes, updateBytes, applyMs, projectionMs,
        framing: "JSON event bodies; excludes SSE/HTTP/TCP overhead", projectionIncludesSynchronousTransportAndApply: true };
    const expected = Array.from({ length: workload.streamChunks }, (_, index) => content(index, workload.chunkBytes, "stream")).join("");
    const finalView = api.readSessionView(replica.chat, replica.session);
    const actual = finalView.entries.filter((entry: any) => entry.role === "assistant")
        .flatMap((entry: any) => entry.blocks).filter((block: any) => block.type === "text")
        .map((block: any) => block.text).join("");
    result.validation = validateText(actual, expected);
    invariant((replica.session.getMap("root").get("session") as Y.Map<unknown>).get("activeTurnStatus") === "completed", "replica completion");
    result.validation.activeTurnStatus = "completed";
    result.capabilities = { resume: "not supported by baseline demo bridge", slowConsumer: "not supported",
        versionedPayloadRead: "not supported", duplicateOutOfOrder: "not evaluated through bridge; Yjs primitive support is separate" };
    connection.unsubscribe(); stream.close(); docs.destroy(); replica.chat.destroy(); replica.session.destroy();
    budget.checkpoint("stream_verified", workload.streamChunks);
}
